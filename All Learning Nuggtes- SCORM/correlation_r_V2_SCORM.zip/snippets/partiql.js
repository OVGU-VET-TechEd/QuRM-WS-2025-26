ace.require(["ace/snippets/partiql"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
