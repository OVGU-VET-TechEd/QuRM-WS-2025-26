ace.require(["ace/snippets/typescript"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
