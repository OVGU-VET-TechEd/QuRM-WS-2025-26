ace.require(["ace/snippets/tsv"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
