ace.require(["ace/snippets/apex"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
