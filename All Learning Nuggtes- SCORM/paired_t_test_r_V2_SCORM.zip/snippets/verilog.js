ace.require(["ace/snippets/verilog"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
