ace.require(["ace/snippets/csharp"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
