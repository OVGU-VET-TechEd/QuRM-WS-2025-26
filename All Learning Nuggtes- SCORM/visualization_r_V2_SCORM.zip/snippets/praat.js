ace.require(["ace/snippets/praat"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
