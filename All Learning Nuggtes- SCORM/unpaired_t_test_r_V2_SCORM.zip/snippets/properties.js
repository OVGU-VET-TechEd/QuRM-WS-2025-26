ace.require(["ace/snippets/properties"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
